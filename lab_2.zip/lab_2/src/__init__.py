"""Adaptive arithmetic encoding/decoding package"""
